define({
    'zh_cn': {
        'Allowed values:'             : '允许值:',
        'Compare all with predecessor': '与所有较早的比较',
        'compare changes to:'         : '将当前版本与指定版本比较:',
        'compared to'                 : '相比于',
        'Default value:'              : '默认值:',
        'Description'                 : '描述',
        'Field'                       : '字段',
        'General'                     : '概要',
        'Generated with'              : '基于',
        'Name'                        : '名称',
        'No response values.'         : '无返回值.',
        'optional'                    : '可选',
        'Parameter'                   : '参数',
        'Permission:'                 : '权限:',
        'Response'                    : '返回',
        'Send'                        : '发送',
        'Send a Sample Request'       : '发送示例请求',
        'show up to version:'         : '显示到指定版本:',
        'Size range:'                 : '取值范围:',
        'Type'                        : '类型',
        'url'                         : '网址'
    }
});
